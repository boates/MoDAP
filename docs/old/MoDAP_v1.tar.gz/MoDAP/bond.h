#ifndef GUARD_bond_h
#define GUARD_bond_h
////////// MoDAP //////////
// bond.h
// Author: Brian Boates
///////////////////////////
#include <string>
#include <vector>

//================================
// bond class
//--------------------------------
class bond {
public:
	// constructors
	bond(atom a1,atom a2,double len);
	
	// fields
	std::pair<atom,atom> atoms;
	double length;
	
	// methods
	void print() const;
	void print(std::string) const;
	
	// operators
	bool operator==(const bond& b) const;
	bool operator> (const bond& b) const;
	bool operator>=(const bond& b) const;
	bool operator< (const bond& b) const;
	bool operator<=(const bond& b) const;
};
//================================

#endif