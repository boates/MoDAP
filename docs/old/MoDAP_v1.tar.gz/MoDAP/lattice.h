#ifndef GUARD_lattice_h
#define GUARD_lattice_h
////////// MoDAP //////////
// lattice.h
// Author: Brian Boates
///////////////////////////
#include <string>
#include <vector>

//================================
// lattice class
//--------------------------------
class lattice {
public:
	// constructors
	lattice(); // default
	lattice(double); // cubic
	lattice(double,double,double); // orthorhombic
	lattice(double ax,double ay,double az,double bx,double by,double bz,double cx,double cy,double cz);
	lattice(std::vector<double>,std::vector<double>,std::vector<double>); // monoclinic
	
	// fields
	double amag, bmag, cmag;
	double alpha, beta, gamma; // alpha = cb, beta = ac, gamma = ab
	double ax, ay, az;
	double bx, by, bz;
	double cx, cy, cz;
	double vol;
	
	// methods
	std::vector<double> a() const;
	std::vector<double> b() const;
	std::vector<double> c() const;
	std::vector<double> angles();
	double volume();
	void print() const;
};
//================================

#endif