////////// MoDAP //////////
// lattice.cpp
// Author: Brian Boates
///////////////////////////
#include <string>
#include <vector>
#include <cmath>
#include <iostream>
#include "utils.h"
#include "lattice.h"
using namespace std;

//============================================================
// members of lattice class (constructors, methods, etc.)
//------------------------------------------------------------
// constructors
lattice::lattice(){
	amag=0; bmag=0; cmag=0;
	alpha=90; beta=90; gamma=90;
	ax=0; ay=0; az=0;
	bx=0; by=0; bz=0;
	cx=0; cy=0; cz=0;
	this->vol=NULL;
};
lattice::lattice(double alat){
	amag=alat; bmag=alat; cmag=alat;
	alpha=90; beta=90; gamma=90;
	ax=alat; ay=0; az=0;
	bx=0; by=alat; bz=0;
	cx=0; cy=0; cz=alat;
	this->volume();
};
lattice::lattice(double alat,double blat,double clat){
	amag=alat; bmag=blat; cmag=clat;
	alpha=90; beta=90; gamma=90;
	ax=alat; ay=0; az=0;
	bx=0; by=blat; bz=0;
	cx=0; cy=0; cz=clat;
	this->volume();
};
lattice::lattice(double ax0,double ay0,double az0,
                 double bx0,double by0,double bz0,
                 double cx0,double cy0,double cz0){
	ax=ax0; ay=ay0; az=az0;
	bx=bx0; by=by0; bz=bz0;
	cx=cx0; cy=cy0; cz=cz0;
	amag=magnitude(this->a());
	bmag=magnitude(this->b());
	cmag=magnitude(this->c());
	this->volume();
	this->angles();
};
lattice::lattice(vector<double> avec,vector<double> bvec,vector<double> cvec){
	amag=magnitude(avec); bmag=magnitude(bvec); cmag=magnitude(cvec);
	ax=avec[0]; ay=avec[1]; az=avec[2];
	bx=bvec[0]; by=bvec[1]; bz=bvec[2];
	cx=cvec[0]; cy=cvec[1]; cz=cvec[2];
	this->angles();
	this->volume();
};
// methods
vector<double> lattice::a() const{
	vector<double> avec;
	avec.push_back(this->ax);
	avec.push_back(this->ay);
	avec.push_back(this->az);
	return avec;
};
vector<double> lattice::b() const{
	vector<double> bvec;
	bvec.push_back(this->bx);
	bvec.push_back(this->by);
	bvec.push_back(this->bz);
	return bvec;
};
vector<double> lattice::c() const{
	vector<double> cvec;
	cvec.push_back(this->cx);
	cvec.push_back(this->cy);
	cvec.push_back(this->cz);
	return cvec;
};
vector<double> lattice::angles() {
	// compute lattice vector angles
	this->alpha = angle(this->b(),this->c());
	this->beta  = angle(this->a(),this->c());
	this->gamma = angle(this->a(),this->b());

    // build angle vector to return
	vector<double> angs;
	angs.push_back(this->alpha);
	angs.push_back(this->beta);
	angs.push_back(this->gamma);

	return angs;
};
double lattice::volume() {
	this->vol = abs( dot(this->a(), cross(this->b(),this->c())) );
	return this->vol;
};
void lattice::print() const{
	// print lattice
	cout << "#" << endl << "# ====== printing lattice ====== #" << endl;
    cout << "#" << endl;

	// print magnitudes
	cout << "# amag, bmag, cmag = ";
	cout << amag << ", " << bmag << ", " << cmag << endl;
	cout << "# alpha, beta, gamma = ";
	cout << alpha << ", " << beta << ", " << gamma << endl;
	cout << "# volume = " << vol << endl;
    cout << "#" << endl;

    cout << "# ax, ay, az = ";
	cout << ax << ", " << ay << ", " << az << endl;
    cout << "# bx, by, bz = ";
	cout << bx << ", " << by << ", " << bz << endl;
    cout << "# cx, cy, cz = ";
	cout << cx << ", " << cy << ", " << cz << endl;
    cout << "#" << endl;

	cout << "# ====== end of lattice ======== #" << endl << "#" << endl;
};
//============================================================

