////////// MoDAP //////////
// bond.cpp
// Author: Brian Boates
///////////////////////////
#include <string>
#include <vector>
#include <iostream>

#include "atom.h"
#include "bond.h"
using namespace std;

//============================================================
// members of bond class (constructors, methods, etc.)
//------------------------------------------------------------
// constructors
bond::bond(atom a1, atom a2, double len){
	this->atoms.first  = a1;
	this->atoms.second = a2;
	this->length = len;
};
// methods
void bond::print() const{
    // print atoms and length
	cout << "{ ";
	(this->atoms.first).print();
	cout << ", ";
	(this->atoms.second).print();
	cout << ", length: " << length << " }" << endl;
};
void bond::print(string str) const{
    // print atoms
    if (str == "atoms") {
    	cout << "{ ";
    	(this->atoms.first).print();
    	cout << ", ";
    	(this->atoms.second).print();
		cout << " }" << endl;
    }
    // print bonds
    else if (str == "length") {
	    cout << "length: " << length << endl;
    }
    // print options
    else
		cout << "options: \"atoms\", \"length\" (all: give no arg)" << endl;
};
// operators
bool bond::operator==(const bond& b) const{

	// compare atom pair and length
	bool cond1 = this->atoms.first == b.atoms.first &&
                 this->atoms.second == b.atoms.second &&
	             this->length == b.length;
	
	// *and* compare reversed atom pair and length
	bool cond2 = this->atoms.first == b.atoms.second &&
	             this->atoms.second == b.atoms.first &&
	             this->length == b.length;

    // return true if either one is true
	return cond1 || cond2;
//	return this->atoms == b.atoms && this->length == b.length;
	
};
bool bond::operator> (const bond& b) const{
	return this->length > b.length;
};
bool bond::operator>=(const bond& b) const{
	return this->length >= b.length;
};
bool bond::operator< (const bond& b) const{
	return this->length < b.length;
};
bool bond::operator<=(const bond& b) const{
	return this->length <= b.length;
};
//============================================================









