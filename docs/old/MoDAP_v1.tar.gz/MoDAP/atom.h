#ifndef GUARD_atom_h
#define GUARD_atom_h
////////// MoDAP //////////
// atom.h
// Author: Brian Boates
///////////////////////////
#include <string>
#include <vector>
#include "lattice.h"

//================================
// atom class
//--------------------------------
class atom {
public:
	// constructors
	atom();
	atom(std::string);
	atom(int);
	atom(std::string, int);
	atom(double,double,double);
	atom(double,double,double,lattice);
	atom(std::string,double,double,double);
	atom(std::string,double,double,double,lattice);
	atom(std::string,int,double,double,double);
	atom(std::string,int,double,double,double,lattice);
	
	// destructor
//	~atom();
	
	// fields 
	std::string type;
	int index; // beginning at 1!
	double a, b, c, x, y, z; // reduced and cartesian coords
	
	// methods
	void assign(std::string,int,double,double,double,lattice);
	std::vector<double> rred() const;
	double xcart(lattice) const;
	double ycart(lattice) const;
	double zcart(lattice) const;
	std::vector<double> rcart(lattice) const;
	void set_cart(lattice);
	void print() const;
	
	// operators
	bool operator==(const atom& a) const;
};
//================================

#endif