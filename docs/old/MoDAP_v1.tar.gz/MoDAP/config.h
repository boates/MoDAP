#ifndef GUARD_config_h
#define GUARD_config_h
////////// MoDAP //////////
// config.h
// Author: Brian Boates
///////////////////////////
#include <string>
#include <vector>
#include <list>
#include <map>
#include <iostream>

//================================
// config class
//--------------------------------
class config {
public:
	// constructors
	config();
	
	// fields
	int natom;
	int ntypes;
	int nbond;
	int nmol;
	int tstep;
	lattice lat;
	std::vector<int> natoms;
//	std::map<std::string,int> natoms;
	std::vector<std::string> types;
	std::vector<atom> atoms;
	std::vector<bond> bonds;
	std::list<molecule> mols;
	
	// methods
	int get_natom() const;
	int get_natom(const std::string&) const;
	int get_ntypes() const;
	int get_nbond() const;
	int get_nmol() const;
	int read_trj(std::ifstream& trj);
	void write_trj(std::ofstream& trj);
	int read_poscar(std::ifstream& poscar);
	int read_xdatcar(std::ifstream& xdatcar, const config& cfg);
	void read_xyz(std::ifstream& xyz);
	void write_xyz(std::ofstream& xyz);
	void wrap();
	config supercell(const int&, const int&, const int&);
//	std::list<double> distances(const std::string&);
	std::list<double> distances(const std::string&, const std::string&);
	void molecules(std::map<std::string,double>& cutoffs);
	
	// operators
	config& operator+=(const atom& a);
	config& operator+=(const bond& b);
	config& operator+=(const molecule& m);
private:
	// methods
	void merge_molecules();
};
//================================

#endif