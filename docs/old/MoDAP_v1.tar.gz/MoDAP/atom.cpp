////////// MoDAP //////////
// atom.cpp
// Author: Brian Boates
///////////////////////////
#include <string>
#include <vector>
#include <iostream>

#include "lattice.h"
#include "atom.h"
using namespace std;

//============================================================
// members of atom class (constructors, methods, etc.)
//------------------------------------------------------------
// constructors
atom::atom(){
	type = "X"; // all atoms must have type, X is default
	index = 0;  // idexing starts at one, 0 set as default
	a=0; b=0; c=0; // lattice vector (reduced) coordinates
	x=0; y=0; z=0; // cartesian coordinates
};
atom::atom(string str){
	type = str;
	index = 0;
	a=0; b=0; c=0; // lattice vector (reduced) coordinates
	x=0; y=0; z=0;
};
atom::atom(int ind){
	type = "X";
	index = ind;
	a=0; b=0; c=0; // lattice vector (reduced) coordinates
	x=0; y=0; z=0;
};
atom::atom(string str, int ind){
	type = str;
	index = ind;
	a=0; b=0; c=0; // lattice vector (reduced) coordinates
	x=0; y=0; z=0;
};
atom::atom(double a0, double b0, double c0){
	type = "X";
	index = 0;
	a=a0; b=b0; c=c0; // lattice vector (reduced) coordinates

	// careful here, included for flexibility
	double x0=a0; double y0=b0; double z0=c0;
	x=x0; y=y0; z=z0;
};
atom::atom(double a0, double b0, double c0, lattice lat){
	type = "X";
	index = 0;
	a=a0; b=b0; c=c0; // lattice vector (reduced) coordinates
	this->x = this->xcart(lat);
	this->y = this->ycart(lat);
	this->z = this->zcart(lat);
};
atom::atom(string str, double a0, double b0, double c0){
	type = str;
	index = 0;
	a=a0; b=b0; c=c0; // lattice vector (reduced) coordinates
	
	// careful here, included for flexibility
	double x0=a0; double y0=b0; double z0=c0;
	x=x0; y=y0; z=z0;
};
atom::atom(string str, double a0, double b0, double c0, lattice lat){
	type = str;
	index = 0;
	a=a0; b=b0; c=c0; // lattice vector (reduced) coordinates
	this->x = this->xcart(lat);
	this->y = this->ycart(lat);
	this->z = this->zcart(lat);
};
atom::atom(string str, int ind, double a0, double b0, double c0){
	type = str;
	index = ind;
	a=a0; b=b0; c=c0; // lattice vector (reduced) coordinates

	// careful here, included for flexibility
	double x0=a0; double y0=b0; double z0=c0;
	x=x0; y=y0; z=z0;
};
atom::atom(string str, int ind, double a0, double b0, double c0, lattice lat){
	type = str;
	index = ind;
	a=a0; b=b0; c=c0; // lattice vector (reduced) coordinates
	this->x = this->xcart(lat);
	this->y = this->ycart(lat);
	this->z = this->zcart(lat);
};
// destructor
/*
atom::~atom(){
	delete &type;
	delete &index;
	delete &a, &b, &c;
	delete &x, &y, &z;
};
*/
// methods
void atom::assign(string str, int ind, double a0, double b0, double c0, lattice lat){
	// same as corresponding constructor
	type = str;
	index = ind;
	a=a0; b=b0; c=c0; // lattice vector (reduced) coordinates
	this->x = this->xcart(lat);
	this->y = this->ycart(lat);
	this->z = this->zcart(lat);
};
vector<double> atom::rred() const{
	// r() in reduced coordinates
	vector<double> rvec;
	rvec.push_back(this->a);
	rvec.push_back(this->b);
	rvec.push_back(this->c);
	return rvec;	
};
double atom::xcart(lattice lat) const{
	// compute cartesian x coordinate from reduced ones
	double xval = this->a*lat.ax + this->b*lat.bx + this->c*lat.cx;
	return xval;
};
double atom::ycart(lattice lat) const{
	// compute cartesian y coordinate from reduced ones
	double yval = this->a*lat.ay + this->b*lat.by + this->c*lat.cy;
	return yval;
};
double atom::zcart(lattice lat) const{
	// compute cartesian z coordinate from reduced ones
	double zval = this->a*lat.az + this->b*lat.bz + this->c*lat.cz;
	return zval;
};
vector<double> atom::rcart(lattice lat) const{
	// build cartesian r vector
	vector<double> rvec;
	rvec.push_back(this->xcart(lat));
	rvec.push_back(this->ycart(lat));
	rvec.push_back(this->zcart(lat));
	return rvec;
};
void atom::set_cart(lattice lat) {
	// compute and set cartesian coordinates
	this->x = this->a*lat.ax + this->b*lat.bx + this->c*lat.cx;
	this->y = this->a*lat.ay + this->b*lat.by + this->c*lat.cy;
	this->z = this->a*lat.az + this->b*lat.bz + this->c*lat.cz;
};
void atom::print() const{
    // print atom type and coordinates
	cout << index << ":[" << type << ", " << a << ", " << b << ", " << c << "]";
};
// operators
bool atom::operator==(const atom& at) const{
	return this->type==at.type && this->index==at.index && this->a==at.a && this->b==at.b && this->c==at.c;
//	return this->type == at.type && this->x-at.x<1E-6 && this->y-at.y<1E-6 && this->z-at.z<1E-6
};
//============================================================


